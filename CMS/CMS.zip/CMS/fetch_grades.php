<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'teacher'])) {
    exit;
}

$class_id = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
$subject_id = isset($_GET['subject_id']) ? (int)$_GET['subject_id'] : 0;
$term = isset($_GET['term']) ? trim($_GET['term']) : '';
$mode = isset($_GET['mode']) ? $_GET['mode'] : 'edit';

if ($class_id <= 0) {
    echo "";
    exit;
}

// Determine if we are in "View Percentage" mode (View mode with no subject selected)
$view_percentage_mode = ($mode === 'view' && $subject_id <= 0);

if ($view_percentage_mode) {
    // Fetch students and their total score for the term
    // We will calculate percentage based on total subjects in the class
    $sql = "SELECT s.id, s.std_id, s.full_name, g.guardian_name, 
            SUM(gr.score) as total_score, COUNT(gr.id) as graded_count
            FROM students s
            LEFT JOIN guardians g ON s.guardian_id = g.id
            LEFT JOIN grades gr ON s.id = gr.student_id AND gr.term = ?
            WHERE s.class_id = ?
            AND s.deleted_at IS NULL
            GROUP BY s.id
            ORDER BY s.full_name";
            
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $term, $class_id);
    $stmt->execute();
    $res = $stmt->get_result();
} else {
    // Fetch students and their score for a specific subject
    $sql = "SELECT s.id, s.std_id, s.full_name, g.guardian_name,
            gr.score as current_score
            FROM students s
            LEFT JOIN guardians g ON s.guardian_id = g.id
            LEFT JOIN grades gr ON s.id = gr.student_id AND gr.subject_id = ? AND gr.term = ?
            WHERE s.class_id = ?
            AND s.deleted_at IS NULL
            ORDER BY s.full_name";
            
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isi", $subject_id, $term, $class_id);
    $stmt->execute();
    $res = $stmt->get_result();
}

$counter = 1;

// Get class name for roll no generation
$c_name_res = $conn->query("SELECT name FROM classes WHERE id = $class_id");
$c_name_row = $c_name_res->fetch_assoc();
$c_name = $c_name_row['name'] ?? '';

if ($res && $res->num_rows > 0) {
    while($row = $res->fetch_assoc()) {
        // Roll No Logic
        $class_num = preg_replace('/[^0-9]/', '', $c_name);
        $prefix = ($class_num !== '') ? $class_num : $class_id;
        $roll_no = $prefix . str_pad($counter++, 2, '0', STR_PAD_LEFT);
        
        $val = isset($row['current_score']) ? $row['current_score'] : '';

        echo "<tr>";
        echo "<td data-label='Roll No'><strong>$roll_no</strong></td>";
        echo "<td data-label='Std ID' style='color: #00d4ff; font-weight: bold;'>" . htmlspecialchars($row['std_id'] ?? 'N/A') . "</td>";
        echo "<td data-label='Name'>" . htmlspecialchars($row['full_name']) . "</td>";
        echo "<td data-label='Father Name'>" . htmlspecialchars($row['guardian_name'] ?? '-') . "</td>";
        echo "<td data-label='" . ($view_percentage_mode ? 'Percentage' : 'Score') . "'>";
        if ($mode === 'view') {
            if ($view_percentage_mode) {
                $obtained = isset($row['total_score']) ? (int)$row['total_score'] : 0;
                $graded_count = isset($row['graded_count']) ? (int)$row['graded_count'] : 0;
                $max_marks = $graded_count * 100;
                if ($max_marks > 0) {
                    echo round(($obtained / $max_marks) * 100, 2) . "%";
                } else {
                    echo "N/A";
                }
            } else {
                echo ($val !== '' ? $val : '-');
            }
        } else {
            echo "<input type='number' name='grades[{$row['id']}]' value='$val' min='0' max='100' style='width: 80px; padding: 0.5rem; border: 1px solid #333; border-radius: 4px; background: #1a1a1a; color: #fff;'>";
        }
        echo "</td>";
        
        if ($mode === 'view') {
            echo "<td data-label='DMC'>";
            if (!empty($term)) {
                echo "<a href='view_dmc.php?student_id={$row['id']}&term=" . urlencode($term) . "' target='_blank' class='action-btn edit' style='text-decoration:none; font-size: 0.8rem; display:inline-block; text-align:center;'>View DMC</a>";
            } else {
                echo "<span style='color:#666; font-size:0.8rem; font-style:italic;'>Enter Term</span>";
            }
            echo " <a href='view_past_performance.php?student_id={$row['id']}' target='_blank' class='action-btn edit' style='text-decoration:none; display:inline-block; text-align:center; background: #8b5cf6; border-color: #8b5cf6; color: white; font-size: 0.75rem; margin-top: 5px; padding: 0.4rem 0.6rem;'>Past Performance</a>";
            echo "</td>";
        }
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='4' style='text-align:center; padding: 2rem;'>No students found.</td></tr>";
}
?>